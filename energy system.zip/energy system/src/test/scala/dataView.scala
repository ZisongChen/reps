import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import scala.io.Source
import scala.io.StdIn.readLine
import java.time.format.DateTimeParseException

object dataView {
  case class DataPoint(dateTime: LocalDateTime, hydro: Double, wind: Double, solar: Double, consumption: Double, storage: Double)

  def main(args: Array[String]): Unit = {
    val maxStorageCapacity = 50000
    var continue = true
    while (continue) {

      val data = readData("D:\\作业\\论文\\dmm2\\output2.csv")
      val sortedData = data.sortBy(_.dateTime)

      println("Latest energy production, consumption, and storage data:")

      val firstDataPoint = sortedData.head
      val latestDataPoint = sortedData.last

      displayCurrentData(firstDataPoint, "Start of the record", maxStorageCapacity)
      displayCurrentData(latestDataPoint, "End of the record", maxStorageCapacity)

      var BeDay: LocalDateTime = null
      var FiDay: LocalDateTime = null
      val formatter = DateTimeFormatter.ofPattern("yyyy/M/d H:mm")

      do {
        try {
          println("Enter start time (yyyy/M/d H:mm):")
          val startTime = readLine()
          BeDay = LocalDateTime.parse(startTime, formatter)

          println("Enter end time (yyyy/M/d H:mm):")
          val endTime = readLine()
          FiDay = LocalDateTime.parse(endTime, formatter)

          if (BeDay.isAfter(FiDay)) {
            println("Start time must be before end time. Please try again.")
            BeDay = null
            FiDay = null
          }
        } catch {
          case _: DateTimeParseException =>
            println("Invalid date format. Please use the format: yyyy/M/d H:mm")
        }
      } while (BeDay == null || FiDay == null)

      val filteredData = filterData(data, BeDay, FiDay)

      val (totalHydro, totalWind, totalSolar) = calculateTotalEnergy(filteredData)

      val (hydroPercentage, windPercentage, solarPercentage) = calculateEnergyPercentages(totalHydro, totalWind, totalSolar)

      val lowProductionTimes = findLowProductionTimes(filteredData, 400)

      val (minStorage, maxStorage) = findMinMaxStorage(filteredData)

      val (totalConsumption, productionConsumptionRatio, highestConsumption, lowestConsumption) = findConsumptionStats(filteredData)



      printPieChart(totalHydro, totalWind, totalSolar)
      println(s"Percentage of total energy produced for the time period: Hydro: $hydroPercentage%, Wind: $windPercentage%, Solar: $solarPercentage%")
      println()
      println(s"Low generation times (below 400): $lowProductionTimes")
      println(s"Lowest storage: ${minStorage.dateTime} (${minStorage.storage})")
      println(s"Highest storage: ${maxStorage.dateTime} (${maxStorage.storage})")
      println()
      println(s"Total energy consumption for the time period: $totalConsumption")
      println(s"Ratio of total energy production to total energy consumption: $productionConsumptionRatio")
      println()
      println(s"Time of highest consumption: ${highestConsumption.dateTime} (${highestConsumption.consumption})")
      println(s"Time of lowest consumption: ${lowestConsumption.dateTime} (${lowestConsumption.consumption})")
      println("----------------------------")
      println("Do you want to analyze more data? (Yes/No)")
      continue = readLine().toLowerCase == "yes"
    }
  }


  def readData(filename: String): List[DataPoint] = {
    val formatter = DateTimeFormatter.ofPattern("yyyy/M/d H:mm")
    val lines = Source.fromFile(filename).getLines().drop(1) // Skip header

    val parsedLines = lines
      .map { line =>
        val Array(dateTimeStr, energyType, electricity, totalElectricity) = line.split(",").map(_.trim)
        val dateTime = LocalDateTime.parse(dateTimeStr, formatter)
        (dateTime, energyType, electricity.toDouble, totalElectricity.toDouble)
      }
      .toList
      .groupBy(_._1)

    parsedLines.map {
      case (dateTime, energyData) =>
        val hydro = energyData.find(_._2 == "HydroPower").map(_._3).getOrElse(0.0)
        val wind = energyData.find(_._2 == "WindPower").map(_._3).getOrElse(0.0)
        val solar = energyData.find(_._2 == "SolarPower").map(_._3).getOrElse(0.0)
        val consumption = energyData.find(_._2 == "Consume").map(_._3).getOrElse(0.0)
        val storage = energyData.find(_._2 == "Consume").map(_._4).getOrElse(0.0)

        DataPoint(dateTime, hydro, wind, solar, consumption, storage)
    }.toList
  }


  def filterData(data: List[DataPoint], BeDay: LocalDateTime, FiDay: LocalDateTime): List[DataPoint] = {
    data.filter(d => !d.dateTime.isBefore(BeDay) && !d.dateTime.isAfter(FiDay))
  }

  def calculateTotalEnergy(data: List[DataPoint]): (Double, Double, Double) = {
    data.foldLeft((0.0, 0.0, 0.0)) { case ((hydro, wind, solar), point) =>
      (hydro + point.hydro, wind + point.wind, solar + point.solar)
    }
  }

  def calculateEnergyPercentages(hydro: Double, wind: Double, solar: Double): (Double, Double, Double) = {
    val total = hydro + wind + solar
    (hydro / total * 100, wind / total * 100, solar / total * 100)
  }

  def findLowProductionTimes(data: List[DataPoint], threshold: Double): List[String] = {
    data.sortBy(_.dateTime)
      .filter(point => point.hydro < threshold || point.wind < threshold)
      .map(point => point.dateTime.format(DateTimeFormatter.ofPattern("yyyy/M/d H:mm")))
  }



  def findMinMaxStorage(data: List[DataPoint]): (DataPoint, DataPoint) = {
    data.foldLeft((data.head, data.head)) { case ((min, max), point) =>
      val newMin = if (point.storage < min.storage) point else min
      val newMax = if (point.storage > max.storage) point else max
      (newMin, newMax)
    }
  }

  def findConsumptionStats(data: List[DataPoint]): (Double, Double, DataPoint, DataPoint) = {
    val (highestConsumption, lowestConsumption, totalConsumption) = data.foldLeft((data.head, data.head, 0.0)) {
      case ((highest, lowest, total), point) =>
        (
          if (point.consumption > highest.consumption) point else highest,
          if (point.consumption < lowest.consumption) point else lowest,
          total + point.consumption
        )
    }

    val totalEnergyProduction = data.map(point => point.hydro + point.wind + point.solar).sum
    val productionConsumptionRatio = totalEnergyProduction / totalConsumption

    (totalConsumption, productionConsumptionRatio, highestConsumption, lowestConsumption)
  }

  // Add a new parameter for the maximum storage capacity
  def displayCurrentData(dataPoint: DataPoint, title: String, maxStorageCapacity: Double): Unit = {
    println(s"$title (${dataPoint.dateTime}):")
    printPieChart(dataPoint.hydro,dataPoint.wind,dataPoint.solar)
    println(s"Consumption: ${dataPoint.consumption}")
    printFanChart(dataPoint.storage, maxStorageCapacity)
    println("----------------------------")
  }

  // New function to print the fan chart
  def printFanChart(currentStorage: Double, maxStorageCapacity: Double): Unit = {
    val totalSegments = 20
    val storageRatio = currentStorage / maxStorageCapacity
    val usedSegments = (storageRatio * totalSegments).round.toInt
    val unusedSegments = totalSegments - usedSegments

    val usedRepresentation = "▒" * usedSegments
    val unusedRepresentation = "░" * unusedSegments

    println(s"Storage: $usedRepresentation$unusedRepresentation ${storageRatio * 100} %     currentStorage: $currentStorage/50000")
  }



  def printPieChart(a: Double, b: Double, c: Double): Unit = {
    val (hydroPercentage, windPercentage, solarPercentage) = calculateEnergyPercentages(a, b, c)
    val totalSegments = 20
    val hydroSegments = (hydroPercentage / 100 * totalSegments).round.toInt
    val windSegments = (windPercentage / 100 * totalSegments).round.toInt
    val solarSegments = totalSegments - (hydroSegments + windSegments)

    val hydroRepresentation = "█" * hydroSegments
    val windRepresentation = "█" * windSegments
    val solarRepresentation = "█" * solarSegments

    println(s"Hydro:  $hydroRepresentation $hydroPercentage%          $a")
    println(s"Wind:   $windRepresentation $windPercentage%            $b  ")
    println(s"Solar:  $solarRepresentation $solarPercentage%          $c")
  }


}